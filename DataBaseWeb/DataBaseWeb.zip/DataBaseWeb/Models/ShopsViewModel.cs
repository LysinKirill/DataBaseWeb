﻿using DataBaseLib;
using NewVariant.Models;

namespace DataBaseWeb.Models;

public class ShopsViewModel
{
    public List<Shop>? Shops { get; set; }
}
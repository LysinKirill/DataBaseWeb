﻿using DataBaseLib;
using NewVariant.Models;

namespace DataBaseWeb.Models;

public class SalesViewModel
{
    public List<Sale>? Sales { get; set; }
}
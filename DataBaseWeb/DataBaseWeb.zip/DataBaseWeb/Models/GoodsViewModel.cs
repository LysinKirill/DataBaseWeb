﻿using DataBaseLib;
using NewVariant.Models;

namespace DataBaseWeb.Models;

public class GoodsViewModel
{
    public List<Good>? Goods { get; set; }
}
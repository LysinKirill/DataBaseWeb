﻿using DataBaseLib;
using NewVariant.Models;

namespace DataBaseWeb.Models;

public class BuyersViewModel
{
    public List<Buyer>? Buyers { get; set; }
}